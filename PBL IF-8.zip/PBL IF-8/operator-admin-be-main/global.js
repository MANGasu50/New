const Global = {
  PRIVATE_KEY: 'operatorbe'
};

module.exports = Global;
