import React from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../assets/images/logo.png';
import { Box } from '@mui/material';

const Navbar = () => {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem('auth');
    navigate('/', {replace: true});
  }

  return (
    <header class="header">
      <div class="frame" style={{ marginLeft: '-30%' }}>
        <div class="logo">
          <img src={Logo} alt="Logo" />
        </div>
      </div>

      <div class="frame2"></div>

      <div class="search-profile">
        <div className="search-box">
          <input type="text" placeholder="Search..." />
          <i className="fas fa-search"></i>
        </div>
        <Box className="profile" style={{ textDecoration: 'none', cursor: 'pointer' }} onClick={logout}>
          <i className="fas fa-user-circle"></i>
          <span>Logout</span>
        </Box>
      </div>
    </header>
  );
};

export default Navbar;
