import React, { useEffect, useState } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar";
import axios from "axios";

const Dashboard = () => {
  const navigate = useNavigate();
  const [robots, setRobots] = useState([]);

  useEffect(() => {
    const authLocal = localStorage.getItem('auth');

    if (!authLocal) {
      navigate('/', {replace: true});
    }

    if (authLocal) {
      const auth = JSON.parse(authLocal);

      if (auth.type === 'admin') {
        navigate('/dashboard', {replace: true});
      }
    }
  }, [navigate]);

  useEffect(() => {
    loadRobots();
  }, []);

  const loadRobots = async () => {
    try {
      const { REACT_APP_BASE_URL } = process.env;

      const robotResponse = await axios.get(REACT_APP_BASE_URL + '/robot', {
        headers: {
          Authorization: localStorage.getItem('token'),
        }
      });
      const newRobots = robotResponse?.data?.data;

      setRobots(newRobots);
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  return (
    <div className="grid-container-dashboard">
      <Navbar />
      <aside id="sidebar">
        <ul>
          <h2><i className="fas fa-info-circle"></i>Operator</h2>
          {robots.map((robot) => (
            <li>
              <Link to={"/operator/dashboard/robot/" + robot.id}><i className="fas fa-robot"></i>{robot.name}</Link>
            </li>
          ))}
          <li>
            <Link to="/operator/dashboard/maps"><i className="fas fa-map"></i>Maps</Link>
          </li>
        </ul>
      </aside>

      <main className="main-container">
        <Outlet />
      </main>
    </div>
  );
};

export default Dashboard;
