import React, { useEffect } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import Navbar from "../../components/Navbar";

const Dashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const authLocal = localStorage.getItem('auth');

    if (!authLocal) {
      navigate('/', {replace: true});
    }

    if (authLocal) {
      const auth = JSON.parse(authLocal);

      if (auth.type === 'operator') {
        navigate('/operator/dashboard', {replace: true});
      }
    }
  }, [navigate]);

  return (
    <div className="grid-container-dashboard">
      <Navbar />
      <aside id="sidebar">
        <ul>
          <h2><i className="fas fa-info-circle"></i>Admin</h2>
          <li>
            <Link to="/dashboard/operator"><i className="fas fa-users"></i>Operator</Link>
          </li>
          <li>
            <Link to="/dashboard/checkpoint"><i className="fas fa-map"></i>Checkpoint</Link>
          </li>
          <li>
            <Link to="/dashboard/robot"><i className="fas fa-robot"></i>Robot</Link>
          </li>
        </ul>
      </aside>

      <main className="main-container">
        <div className="inner-box-dashboard" style={{marginBottom: '24px'}}>
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
