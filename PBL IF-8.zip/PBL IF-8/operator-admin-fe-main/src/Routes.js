import React from "react";
import { BrowserRouter, Navigate, Routes as ReactRouterRoutes, Route } from "react-router-dom";
import AuthLogin from "./pages/auth/login";
import ContactUs from "./pages/contactus";

import AdminDashboard from "./layout/admindashboard";
import DashboardCheckpoint from "./pages/dashboard/checkpoint";
import DashboardOperator from "./pages/dashboard/operator";
import DashboardRobot from "./pages/dashboard/robot";
import OperatorDashboardRobot from "./pages/operator/dashboard/robot";
import OperatorDashboardMaps from "./pages/operator/dashboard/maps";

import OperatorDashboard from "./layout/operatordashboard";

const Routes = () => {
  return (
    <BrowserRouter>
      <ReactRouterRoutes>
        <Route path={'/'} element={<AuthLogin />} />
        <Route path={'/contactus'} element={<ContactUs />} />
        <Route path={'/dashboard'} element={<AdminDashboard />}>
          <Route index element={<Navigate to={'/dashboard/operator'} />} />
          <Route path={'/dashboard/operator'} element={<DashboardOperator />} />
          <Route path={'/dashboard/checkpoint'} element={<DashboardCheckpoint />} />
          <Route path={'/dashboard/robot'} element={<DashboardRobot />} />
        </Route>
        <Route path={'/operator/dashboard'} element={<OperatorDashboard />}>
          <Route index element={<Navigate to={'/operator/dashboard/maps'} />} />
          <Route path={'/operator/dashboard/robot/:id'} element={<OperatorDashboardRobot />} />
          <Route path={'/operator/dashboard/maps'} element={<OperatorDashboardMaps />} />
        </Route>

      </ReactRouterRoutes>
    </BrowserRouter>
  );
};

export default Routes;
