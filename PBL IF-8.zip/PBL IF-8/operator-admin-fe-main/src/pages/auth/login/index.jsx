import React from 'react';
import Robot2 from '../../../assets/images/robot2.jpg';
import { Helmet } from 'react-helmet';
import useAuthLogin from './action';

const AuthLogin = () => {
  const {formik} = useAuthLogin();

  return (
    <div className="limiter">
      <Helmet>
        <title>Login</title>
      </Helmet>
      <div className="container-login100">
        <div className="wrap-login100">
          <div className="login100-pic js-tilt" data-tilt>
            <img alt={'icon'} src={Robot2} />
          </div>

          <div className="login100-form validate-form">
            <span className="login100-form-title">
              Login
            </span>

            <div className="wrap-input100 validate-input">
              <input value={formik.values.username} className="input100" type="text" name="username" placeholder="Username" onChange={(e) => formik.setFieldValue('username', e.target.value)} />
                <span className="focus-input100"></span>
                <span className="symbol-input100">
                  <i className="fa fa-user" aria-hidden="true"></i>
                </span>
            </div>

            <div className="wrap-input100 validate-input" data-validate="Password is required">
              <input value={formik.values.password} className="input100" type="password" name="pass" placeholder="Password" onChange={(e) => formik.setFieldValue('password', e.target.value)} />
              <span className="focus-input100"></span>
              <span className="symbol-input100">
                <i className="fa fa-lock" aria-hidden="true"></i>
              </span>
            </div>

            <div className="container-login100-form-btn">
              <button className="button" type={'submit'} value={'admin'} style={{marginBottom: '10px'}} onClick={formik.handleSubmit}>
                Login
              </button>
            </div>

            <div className="text-center p-t-180">

            </div>


          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLogin;
