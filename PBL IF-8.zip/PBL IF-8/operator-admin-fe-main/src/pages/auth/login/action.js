import { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import axios from "axios";

const useAuthLogin = () => {
  const navigate = useNavigate();
  const [loginLoading, setLoginLoading] = useState(false);

  useEffect(() => {
    const authLocal = localStorage.getItem('auth');

    if (authLocal) {
      const auth = JSON.parse(authLocal);

      if (auth.type === 'operator') {
        navigate('/operator/dashboard', {replace: true});
      } else {
        navigate('/dashboard', {replace: true});
      }
    }
  }, [navigate]);

  const formik = useFormik({
    initialValues: {
      username: '',
      password: ''
    },
    onSubmit: async (values) => {
      try {
        setLoginLoading(true);

        const {username, password} = values;

        const loginResponse = await axios.post(process.env.REACT_APP_BASE_URL + '/auth/login', {username, password});

        const userType = loginResponse?.data?.data?.type;

        localStorage.setItem('auth', JSON.stringify(loginResponse?.data?.data));
        localStorage.setItem('token', loginResponse?.data?.data?.token);

        if (userType === 'operator') {
          navigate('/operator/dashboard', {replace: true});
        } else {
          navigate('/dashboard', {replace: true});
        }
      } catch (error) {
        alert(error?.response?.data?.message);
      } finally {
        setLoginLoading(false);
      }
    },
  });

  return {
    formik,
    loginLoading,
  };
};

export default useAuthLogin;
