import React from "react";
import Logo from '../../assets/images/logo.png';
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";

const ContactUs = () => {
  return (
    <div class="grid-container">
      <Helmet>
        <title>Contact Us</title>
      </Helmet>
      <header class="header">
        <div class="frame">
          <div class="logo">
            <img src={Logo} alt="Logo" />
          </div>
        </div>

        <div class="frame2"></div>

        <div class="search-profile">
          <div class="search-box">
            <input type="text" placeholder="Search..." />
            <i class="fas fa-search"></i>
          </div>


          <Link to={'/contactus'} className="profile" style={{ textDecoration: 'none' }}>
            <i class="fas fa-envelope"></i>
            <span>Contact Us</span>
          </Link>

          <Link to={'/'} className="profile" style={{ textDecoration: 'none' }}>
            <i class="fas fa-user-circle"></i>
            <span>Login</span>
          </Link>
        </div>
      </header>

      <div class="frame3">
        <div class="body-text">
          <span class="page">Home {'>'} Contact us</span>
          <div class="title-page">
            Contact us
          </div>
          <div class="text-page">
            <div>
              <p>We welcome your inquiries about our products.</p>
              <p>Our staff will respond after confirming receipt of </p>
              <p>your inquiry.</p>
            </div>

            <div class="contact-icons">
              <i class="fas fa-envelope"></i>
              <span>ihsannab213@gmail.com</span>
            </div>

            <div class="contact-icons">
              <i class="fas fa-phone"></i>
              <span>+62(012)-345-678</span>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- submit form --> */}
      <div class="frame4">

        <form action="#" method="post">
          <div class="submit-container m-t-40 ">
            <div class="input-container">
              <span class="collumn-title">Your Name*</span>
              <div class="wrap-input100">
                <input class="input-contact" />
                <span class="focus-input100"></span>
              </div>
            </div>

            <div class="input-container m-t-40">
              <span class="collumn-title">Email*</span>
              <div class="wrap-input100  ">
                <input class="input-contact" />
                <span class="focus-input100"></span>
              </div>
            </div>

            <div class="input-container m-t-40">
              <span class="collumn-title">Message</span>
              <div class="input-message">
                <textarea class="textarea-msg" id="message" name="message"
                  placeholder="Type your message here..."></textarea>
              </div>
            </div>
            <div class="wrap-button">
            </div>
            <div class="button-container">
              <div class="wrap-button">
                <button class="button m-t-25" type="submit" value="submit">
                  Submit
                </button>
              </div>
            </div>


          </div>
        </form>
      </div>
    </div>
  );
};

export default ContactUs;
