import React, { useEffect, useState } from 'react';
import RobotImage from '../../../../assets/images/robot.jpg';
import { Box } from '@mui/material';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const OperatorDashboardRobot = () => {
  const {id: robotId} = useParams();
  const [robotData, setRobotData] = useState(null);

  useEffect(() => {
    loadRobotHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [robotId]);

  const loadRobotHistory = async () => {
    try {
      const { REACT_APP_BASE_URL } = process.env;

      const robotHistoryResponse = await axios.get(REACT_APP_BASE_URL + '/robot/history/' + robotId, {
        headers: {
          Authorization: localStorage.getItem('token'),
        }
      });

      setRobotData(robotHistoryResponse.data?.data);
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  return (
    <Box flex={1} display={'flex'} justifyContent={'center'} alignItems={'center'}>
      <Box className="inner-box-R1">
        <img src={RobotImage} alt="Robot1" />
        <div className="text-container" id="robotInfo">
          <p>Status Lokasi: {robotData?.checkpoint_name}</p>
          <p>Jumlah Baterai: {robotData?.robot_battery}%</p>
          <p>Jenis Robot: {robotData?.robot_type}</p>
          <p>Nomor Seri: {robotData?.robot_series_number}</p>
        </div>
      </Box>
    </Box>
  );
};

export default OperatorDashboardRobot;
