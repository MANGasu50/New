import React from 'react';
import dayjs from 'dayjs';
import { Stepper, Step, StepLabel, Card, Typography, Box } from '@mui/material';
import useOperatorMaps from './action';

const OperatorDashboardMaps = () => {
  const { operatorMaps } = useOperatorMaps();

  return (
    <>
      {operatorMaps.map((operatorMapEachRobot) => (
        <Card sx={{ p: 2, mb: 2 }}>
          <Box display={'flex'} alignItems={'flex-start'} flexDirection={'column'}>
            <Typography mb={2} variant='h6'>{operatorMapEachRobot[0]?.robot_name}</Typography>
            <Stepper orientation='horizontal' alternativeLabel sx={{overflowX: 'auto', width: '100%', pb: 2}}>
              {operatorMapEachRobot.map((operatorHistory) => (
                <Step key={operatorHistory.id}>
                  <StepLabel>
                    {operatorHistory.checkpoint_name}
                    <br />
                    ({operatorHistory.user_name})
                    <br />
                    {dayjs(operatorHistory.created_at).format('DD/MM/YYYY HH:mm')}
                  </StepLabel>
                </Step>
              ))}
            </Stepper>
          </Box>
        </Card>
      ))}
    </>
  );
};

export default OperatorDashboardMaps;
