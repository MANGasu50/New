import axios from "axios";
import { useEffect, useState } from "react";

const useOperatorMaps = () => {
  const [operatorMaps, setOperatorMaps] = useState([]);

  useEffect(() => {
    loadRobotHistory();
  }, []);

  const loadRobotHistory = async () => {
    try {
      const { REACT_APP_BASE_URL } = process.env;

      const operatorMapsResponse = await axios.get(REACT_APP_BASE_URL + '/robot/history', {
        headers: {
          Authorization: localStorage.getItem('token'),
        }
      });
      const newOperatorMaps = operatorMapsResponse?.data?.data;

      setOperatorMaps(Object.values(newOperatorMaps));
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  return {
    operatorMaps,
  };
};

export default useOperatorMaps;
