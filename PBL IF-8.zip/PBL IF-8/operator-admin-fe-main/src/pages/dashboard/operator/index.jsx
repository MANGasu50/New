import React, { useState } from "react";
import dayjs from 'dayjs';
import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from "@mui/material";
import { Helmet } from "react-helmet";
import { Close, Delete, Edit, Refresh, Visibility, VisibilityOff } from '@mui/icons-material';
import useOperatorAction from "./action";

const DashboardOperator = () => {
  const {
    formik,
    handleDelete,
    handleEdit,
    operators,
    setShowModal,
    setVisibleInputPassword,
    showModal,
    visibleInputPassword
  } = useOperatorAction();

  const handleGeneratePassword = () => {
    const randomKeyOptions = [
      'Testtest',
      '@ku12345',
      '@dmin123',
      'haloduni',
      'hahahaha',
      'password'
    ];

    const newPassword = randomKeyOptions[Math.floor(Math.random() * randomKeyOptions.length)];

    formik.setFieldValue('password', newPassword);
  };

  return (
    <div style={{ width: '100%', backgroundColor: '#FFF', minHeight: '300px', borderRadius: '24px', padding: '24px' }}>
      <Helmet>
        <title>Dashboard - Operator</title>
      </Helmet>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Operator</h1>

        <Button variant="contained" onClick={() => setShowModal(true)}>
          Tambah
        </Button>
      </div>

      <Box mt={3}>
        <TableContainer sx={{ maxWidth: '100%', width: '100%', overflowX: 'auto' }}>
          <Table sx={{ whiteSpace: 'nowrap' }}>
            <TableHead>
              <TableRow>
                <TableCell>No</TableCell>
                <TableCell sx={{ textWrap: 'wrap', width: '300px' }}>Nama</TableCell>
                <TableCell sx={{ textWrap: 'wrap', width: '300px' }}>Username</TableCell>
                <TableCell sx={{ textWrap: 'wrap', width: '300px' }}>Password</TableCell>
                <TableCell sx={{ textWrap: 'wrap', width: '300px' }}>Tanggal Lahir</TableCell>
                <TableCell sx={{ textWrap: 'wrap', width: '300px', whiteSpace: 'wrap' }}>Alamat</TableCell>
                <TableCell sx={{ textWrap: 'wrap', width: '300px' }}>Aksi</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {operators.map((d, index) => <RenderRow data={d} handleDelete={handleDelete} handleEdit={handleEdit} index={index} />)}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Dialog open={showModal} onClose={() => setShowModal(false)}>
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          Form Operator
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={() => setShowModal(false)}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
          }}
        >
          <Close />
        </IconButton>
        <DialogContent dividers sx={{ padding: 3, minWidth: '500px', maxWidth: '100%', minHeight: '300px' }}>
          <TextField onChange={(e) => formik.setFieldValue('name', e.target.value)} value={formik.values.name} label={'Nama'} variant={'outlined'} fullWidth sx={{ mb: 2 }} />
          <TextField onChange={(e) => formik.setFieldValue('username', e.target.value)} value={formik.values.username} label={'Username'} variant={'outlined'} fullWidth sx={{ mb: 2 }} />
          <Box mb={2} display={'flex'} alignItems={'stretch'} flexDirection={'row'}>
            <TextField onChange={(e) => formik.setFieldValue('password', e.target.value)} value={formik.values.password} label={'Password'} type={visibleInputPassword ? 'text' : 'password'} variant={'outlined'} sx={{ mr: 2 }} fullWidth InputProps={{
              endAdornment: <IconButton onClick={() => setVisibleInputPassword(!visibleInputPassword)}>
                {visibleInputPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            }} />
            <Button sx={{ px: 4 }} variant="contained" onClick={handleGeneratePassword} endIcon={<Refresh />}>Generate</Button>
          </Box>
          <TextField onChange={(e) => formik.setFieldValue('birthdate', e.target.value)} value={formik.values.birthdate} label={'Tanggal Lahir'} InputLabelProps={{ shrink: true }} variant={'outlined'} type={'date'} fullWidth sx={{ mb: 2 }} />
          <TextField onChange={(e) => formik.setFieldValue('address', e.target.value)} value={formik.values.address} multiline minRows={3} label={'Alamat'} variant={'outlined'} fullWidth sx={{ mb: 2 }} />
        </DialogContent>
        <DialogActions>
          <Button variant="text" onClick={() => setShowModal(false)}>
            Tutup
          </Button>
          <Button variant="contained" onClick={() => formik.handleSubmit()}>
            Simpan
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default DashboardOperator;

const RenderRow = ({ data, index, handleEdit, handleDelete }) => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <TableRow>
      <TableCell>
        {index + 1}
      </TableCell>
      <TableCell>
        {data.name}
      </TableCell>
      <TableCell>
        {data.username}
      </TableCell>
      <TableCell>
        <Box sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
          <span>{showPassword ? data.password : '******'}</span>
          <IconButton color={'primary'} onClick={() => setShowPassword(!showPassword)}>
            {showPassword ? <VisibilityOff /> : <Visibility />}
          </IconButton>
        </Box>
      </TableCell>
      <TableCell>
        {dayjs(data.birthdate).format('DD MMM YYYY')}
      </TableCell>
      <TableCell sx={{ maxWidth: '300px', wordWrap: 'break-word', textWrap: 'wrap' }}>
        {data.address}
      </TableCell>
      <TableCell>
        <Box flexDirection={'row'} display={'flex'} alignItems={'center'}>
          <IconButton color={'warning'} variant="contained" size={'small'} sx={{ mr: 1 }} onClick={() => handleEdit(data)}>
            <Edit />
          </IconButton>
          <IconButton color={'error'} variant="contained" size={'small'} onClick={() => handleDelete(data)}>
            <Delete />
          </IconButton>
        </Box>
      </TableCell>
    </TableRow>
  );
};
