import {useEffect, useState} from 'react';
import axios from 'axios';
import { useFormik } from 'formik';
import dayjs from 'dayjs';

const useOperatorAction = () => {
  
  const [loading, setLoading] = useState(true);
  const [operators, setOperators] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [visibleInputPassword, setVisibleInputPassword] = useState(false);

  const formik = useFormik({
    initialValues: {
      id: null,
      name: '',
      username: '',
      password: '',
      birthdate: '',
      address: '',
      type: '',
    },
    onSubmit: async (values) => {
      try {
        const {id, name, username, password, birthdate, address, type} = values;
  
        if (!id) {
          await axios.post(process.env.REACT_APP_BASE_URL + '/user', {name, username, password, birthdate, address, type: type || 'operator'}, {headers: {
            Authorization: localStorage.getItem('token')
          }});
  
          alert('Operator berhasil dibuat');
        } else {
          await axios.put(process.env.REACT_APP_BASE_URL + '/user/' + id, {name, username, password, birthdate, address, type: type || 'operator'}, {headers: {
            Authorization: localStorage.getItem('token')
          }});
  
          alert('Operator berhasil diubah');
        }
  
        formik.resetForm();
        setShowModal(false);
        loadOperators();
      } catch (error) {
        alert(error?.response?.data?.message);
      }
    }
  });

  useEffect(() => {
    loadOperators();
  }, []);

  useEffect(() => {
    if (!showModal) {
      formik.resetForm();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal]);

  const loadOperators = async () => {
    try {
      setLoading(true);

      const {REACT_APP_BASE_URL} = process.env;
  
      const operatorResponse = await axios.get(REACT_APP_BASE_URL + '/user', {headers: {
        Authorization: localStorage.getItem('token'),
      }});
      const newOperators = operatorResponse?.data?.data;

      setOperators(newOperators);
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  const handleEdit = (d) => {
    setShowModal(true);

    formik.setValues({
      id: d.id,
      name: d.name,
      username: d.username,
      password: d.password,
      birthdate: dayjs(d.birthdate).format('YYYY-MM-DD'),
      address: d.address,
      type: d.type
    });
  };

  const handleDelete = async (d) => {
    if (!window.confirm('Apakah kamu yakin ingin menghapus data ini?')) {
      return;
    }

    try {
      const {REACT_APP_BASE_URL} = process.env;

      await axios.delete(REACT_APP_BASE_URL + '/user/' + d.id, {headers: {
        Authorization: localStorage.getItem('token'),
      }});

      loadOperators();
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  return {
    showModal,
    setShowModal,
    formik,
    handleEdit,
    handleDelete,
    loading,
    operators,
    visibleInputPassword,
    setVisibleInputPassword
  };
};

export default useOperatorAction;
