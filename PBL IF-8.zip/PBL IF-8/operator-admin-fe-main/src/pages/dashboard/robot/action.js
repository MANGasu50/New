import { useEffect, useState } from 'react';
import axios from 'axios';
import { useFormik } from 'formik';

const useRobotAction = () => {
  const [loading, setLoading] = useState(true);
  const [robots, setRobots] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const formik = useFormik({
    initialValues: {
      id: null,
      name: '',
      type: '',
      battery: '',
      series_number: '',
    },
    onSubmit: async (values) => {
      try {
        const { id, name, type, battery, series_number } = values;

        if (!id) {
          await axios.post(process.env.REACT_APP_BASE_URL + '/robot', { name, type, battery, series_number }, {
            headers: {
              Authorization: localStorage.getItem('token')
            }
          });

          alert('Robot berhasil dibuat');
        } else {
          await axios.put(process.env.REACT_APP_BASE_URL + '/robot/' + id, { name, type, battery, series_number }, {
            headers: {
              Authorization: localStorage.getItem('token')
            }
          });

          alert('Robot berhasil diubah');
        }

        formik.resetForm();
        setShowModal(false);
        loadRobots();
      } catch (error) {
        alert(error?.response?.data?.message);
      }
    }
  });

  useEffect(() => {
    loadRobots();
  }, []);

  useEffect(() => {
    if (!showModal) {
      formik.resetForm();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal]);

  const loadRobots = async () => {
    try {
      setLoading(true);

      const { REACT_APP_BASE_URL } = process.env;

      const robotResponse = await axios.get(REACT_APP_BASE_URL + '/robot', {
        headers: {
          Authorization: localStorage.getItem('token'),
        }
      });
      const newRobots = robotResponse?.data?.data;

      setRobots(newRobots);
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  const handleEdit = (d) => {
    setShowModal(true);

    formik.setValues({
      id: d.id,
      name: d.name,
      type: d.type,
      battery: d.battery,
      series_number: d.series_number,
    });
  };

  const handleDelete = async (d) => {
    if (!window.confirm('Apakah kamu yakin ingin menghapus data ini?')) {
      return;
    }

    try {
      const { REACT_APP_BASE_URL } = process.env;

      await axios.delete(REACT_APP_BASE_URL + '/robot/' + d.id, {
        headers: {
          Authorization: localStorage.getItem('token'),
        }
      });

      loadRobots();
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  return {
    showModal,
    setShowModal,
    formik,
    handleEdit,
    handleDelete,
    loading,
    robots
  };
};

export default useRobotAction;
