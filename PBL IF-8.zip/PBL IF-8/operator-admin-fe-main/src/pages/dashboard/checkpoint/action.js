import {useEffect, useState} from 'react';
import {useFormik} from 'formik';
import axios from 'axios';

const useCheckpointAction = () => {
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [checkpoints, setCheckpoints] = useState([]);

  const formik = useFormik({
    initialValues: {
      id: null,
      name: '',
      status: false
    },
    onSubmit: async (values, formik) => {
      try {
        if (!values.id) {
          await axios.post(process.env.REACT_APP_BASE_URL + '/checkpoint', {name: values.name, status: values.status ? true : false}, {headers: {
            Authorization: localStorage.getItem('token')
          }});

          alert('Checkpoint berhasil dibuat');
        } else {
          await axios.put(process.env.REACT_APP_BASE_URL + '/checkpoint/' + values.id, {name: values.name, status: values.status ? true : false}, {headers: {
            Authorization: localStorage.getItem('token')
          }});

          alert('Checkpoint berhasil diubah');
        }

        formik.resetForm();
        setShowModal(false);
        loadCheckpoints();
      } catch (error) {
        alert(error?.response?.data?.message);
      }
    },
  });

  useEffect(() => {
    loadCheckpoints();
  }, []);

  useEffect(() => {
    if (!showModal) {
      formik.resetForm();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal]);

  const loadCheckpoints = async () => {
    try {
      setLoading(true);

      const {REACT_APP_BASE_URL} = process.env;
  
      const checkpointResponse = await axios.get(REACT_APP_BASE_URL + '/checkpoint', {headers: {
        Authorization: localStorage.getItem('token'),
      }});
      const newCheckpoints = checkpointResponse?.data?.data;

      setCheckpoints(newCheckpoints);
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  const handleActive = async (d) => {
    try {
      const {REACT_APP_BASE_URL} = process.env;

      await axios.put(REACT_APP_BASE_URL + '/checkpoint/' + d.id, {name: d.name, status: true}, {headers: {
        Authorization: localStorage.getItem('token'),
      }});

      loadCheckpoints();
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  const handleUnactive = async (d) => {
    try {
      const {REACT_APP_BASE_URL} = process.env;

      await axios.put(REACT_APP_BASE_URL + '/checkpoint/' + d.id, {name: d.name, status: false}, {headers: {
        Authorization: localStorage.getItem('token'),
      }});

      loadCheckpoints();
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  const handleEdit = (d) => {
    setShowModal(true);

    formik.setValues({
      id: d.id,
      name: d.name,
      status: d.status,
    });
  };

  const handleDelete = async (d) => {
    if (!window.confirm('Apakah kamu yakin ingin menghapus data ini?')) {
      return;
    }

    try {
      const {REACT_APP_BASE_URL} = process.env;

      await axios.delete(REACT_APP_BASE_URL + '/checkpoint/' + d.id, {headers: {
        Authorization: localStorage.getItem('token'),
      }});

      loadCheckpoints();
    } catch (error) {
      alert(error?.response?.data?.message);
    }
  };

  return {loading, checkpoints, formik, setShowModal, showModal, handleUnactive, handleActive, handleEdit, handleDelete};
};

export default useCheckpointAction;
