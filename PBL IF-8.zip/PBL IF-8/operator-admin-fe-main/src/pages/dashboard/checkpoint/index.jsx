import React from "react";
import { Helmet } from "react-helmet";
import { Add, Close, Delete, Edit, Remove } from "@mui/icons-material";
import { Box, Button, Chip, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from "@mui/material";
import useCheckpointAction from './action';

const DashboardCheckpoint = () => {
  const { checkpoints, formik, showModal, setShowModal, handleActive, handleUnactive, handleEdit, handleDelete } = useCheckpointAction();

  return (
    <div style={{ width: '100%', backgroundColor: '#FFF', minHeight: '300px', borderRadius: '24px', padding: '24px' }}>
      <Helmet>
        <title>Dashboard - Checkpoint</title>
      </Helmet>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Checkpoint</h1>

        <Button startIcon={<Add />} variant="contained" size={'small'} onClick={() => setShowModal(true)}>
          Tambah Checkpoint
        </Button>
      </div>

      <Box mt={3}>
        <TableContainer sx={{ overflowX: 'auto' }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>No</TableCell>
                <TableCell>Nama</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Aksi</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {checkpoints.map((d, index) => (
                <TableRow>
                  <TableCell>
                    {index + 1}
                  </TableCell>
                  <TableCell sx={{ textWrap: 'wrap', maxWidth: '300px' }}>
                    {d.name}
                  </TableCell>
                  <TableCell sx={{ textWrap: 'wrap', maxWidth: '300px' }}>
                    <Chip label={d.status ? 'Aktif' : 'Non-Aktif'} sx={{ mr: 1, mb: 1 }} />
                  </TableCell>
                  <TableCell>
                    <Box flexDirection={'row'} display={'flex'} alignItems={'center'}>
                      <IconButton color={'primary'} variant="contained" size={'small'} disabled={+d.status} sx={{ mr: 1 }} onClick={() => handleActive(d)}>
                        <Add />
                      </IconButton>
                      <IconButton color={'error'} variant="contained" size={'small'} disabled={!+d.status} sx={{ mr: 1 }} onClick={() => handleUnactive(d)}>
                        <Remove />
                      </IconButton>
                      <IconButton color={'info'} variant="contained" size={'small'} sx={{ mr: 1 }} onClick={() => handleEdit(d)}>
                        <Edit />
                      </IconButton>
                      <IconButton color={'error'} variant="contained" size={'small'} onClick={() => handleDelete(d)}>
                        <Delete />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Dialog open={showModal} onClose={() => setShowModal(false)}>
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
          Form Checkpoint
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={() => setShowModal(false)}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
          }}
        >
          <Close />
        </IconButton>
        <DialogContent dividers sx={{ padding: 3, minWidth: '500px', maxWidth: '100%', minHeight: '300px' }}>
          <TextField value={formik.values.name} label={'Nama'} variant={'outlined'} fullWidth sx={{ mb: 2 }} onChange={(e) => formik.setFieldValue('name', e.target.value)} />
        </DialogContent>
        <DialogActions>
          <Button variant="text" onClick={() => setShowModal(false)}>
            Tutup
          </Button>
          <Button variant="contained" onClick={formik.handleSubmit}>
            Simpan
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default DashboardCheckpoint;
