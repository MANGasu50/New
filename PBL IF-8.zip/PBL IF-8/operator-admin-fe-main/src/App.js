import React from "react";
import Routes from "./Routes";
import { ThemeProvider, createTheme } from "@mui/material";

const theme = createTheme({
  typography: {
    fontFamily: [
      'Poppins-Regular',
      'Poppins-Bold',
      'Poppins-Medium',
      'Montserrat-Bold',
    ].join(','),
  },
  palette: {
    primary: {
      main: '#4E69AC'
    },
    secondary: {
      main: '#4c6aa4'
    }
  }
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <div>
        <Routes />
      </div>
    </ThemeProvider>
  );
}

export default App;
